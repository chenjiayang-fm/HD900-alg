#include "hi_common.h"
#include "hi_comm_sys.h"
#include "hi_ive.h"
#include "hi_comm_ive.h"
#include "mpi_ive.h"
#include "hi_comm_video.h"
#include "mpi_sys.h"
#include "mpi_vpss.h"
#include <opencv2/opencv.hpp>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#define HI_SUCC true
#define HI_FAIL false

int vpss_yuv2mat(VIDEO_FRAME_INFO_S *stVideoFrame, cv::Mat &dstMat);
