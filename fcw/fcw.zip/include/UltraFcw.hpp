
// #ifndef UltraFcw_hpp
// #define UltraFcw_hpp

// #pragma once

#include "gpu.h"
#include "net.h"
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <chrono>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include <unistd.h>

#include <opencv2/opencv.hpp>
#include "ive2mat.hpp"
#include <sstream>

#define num_featuremap 4
#define hard_nms 1
#define blending_nms 2 /* mix nms was been proposaled in paper blaze fcw, aims to minimize the temporal jitter*/

#define PI 3.1415926
#define E 2.7182818

typedef struct fcwInfo {
    float x1;
    float y1;
    float x2;
    float y2;
    float score;
	float ttc;

    float *landmarks;
} fcwInfo;

class UltraFcw {
public:
    UltraFcw(const std::string &bin_path, const std::string &param_path,
              int input_width, int input_length, int num_thread_ = 1, 
              float score_threshold_ = 0.7, float _install_h = 1.4, float _gps_speed = 25, 
              float iou_threshold_ = 0.3, int topk_ = -1);

    ~UltraFcw();

    int hi_detect(VIDEO_FRAME_INFO_S srcFrame, std::vector<fcwInfo> &fcw_info_list);

private:
    ncnn::Net ultrafcw;

	VIDEO_FRAME_INFO_S srcFrame;

    int num_thread;
    int image_w;
    int image_h;

    int in_w;
    int in_h;
    int num_anchors;

    int topk;
    float score_threshold;
    float iou_threshold;

    float install_h {1.4};
    float gps_speed {25.0};

    float beta {18*PI/180};
    float theta {4*PI/180};//4
    float apl {1.4};

    const float mean_vals[3] = {0.f, 0.f, 0.f};
    const float norm_vals[3] = {1/255.f, 1/255.f, 1/255.f};

    const float center_variance = 0.1;
    const float size_variance = 0.2;

};

//#endif /* UltraFcw_hpp */
