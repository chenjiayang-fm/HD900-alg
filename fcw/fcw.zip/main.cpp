
#include "UltraFcw.hpp"

int main()
{
    VIDEO_FRAME_INFO_S stVideoFrame {0};

    //  models path
    std::string bin_path = "../model/a10-fcw-160.bin";
    std::string param_path = "../model/a10-fcw-160.param";
    //  fcw info output
    std::vector<fcwInfo> fcw_info;
    //  set conf output
    float fcw_score_threshold = 0.92;

    UltraFcw ultrafcw(bin_path, param_path, 160, 160, 1, fcw_score_threshold);

    while(1)
    {
        HI_S32 s32Ret = HI_MPI_VPSS_GetChnFrame(0, 2, &stVideoFrame, 2000);
        if (HI_SUCCESS != s32Ret)
        {
            usleep(20000);
            std::cout<< "HI_MPI_VPSS_GetChnFrame failed 0x"<<std::hex<<s32Ret<<std::dec<<std::endl;
            continue;
        }

        ultrafcw.hi_detect(stVideoFrame, fcw_info);

        s32Ret = HI_MPI_VPSS_ReleaseChnFrame(0, 2, &stVideoFrame);

        for (size_t i {}; i < fcw_info.size(); ++i) 
        {
            auto fcw = fcw_info[i];
            std::cout<<"car locate: "<<fcw.x1<<" "<<fcw.x2<<" "<<fcw.y1<<" "<<fcw.y2
                        <<" confidence: "<<fcw.score<<std::endl;
        }
        sleep(1);
    }
}





















/*****************************
int main(int argc, char **argv) {
    // if (argc <= 3) {
    //     fprintf(stderr, "Usage: %s <ncnn bin> <ncnn param> [image files...]\n", argv[0]);
    //     return 1;
    // }

    // std::string bin_path = argv[1];
    // std::string param_path = argv[2];
    // std::string bin_path = "/mnt/MNN/ncnn/version-RFB/fcw.bin";
    // std::string param_path = "/mnt/MNN/ncnn/version-RFB/fcw.param";

    std::string bin_path = "../car_models/160-3-opt.bin";
    std::string param_path = "../car_models/160-3-opt.param";

    UltraFcw ultrafcw(bin_path, param_path, 160, 120, 1, 0.7); // config model input

    char filename[20];
    char image_file[20];
	stringstream str_score;
	string fcw_score;

	Mat cv_frame;
	VIDEO_FRAME_INFO_S videoframeinfo;

    for (int i = 2; i < 29; i++)
	while(1)
	{
		//  located images
        //sprintf(image_file, "../car_imgs/%d.bmp", i-1);
        //std::cout << "Processing " << image_file << std::endl;
        //cv::Mat frame = cv::imread(image_file);
		//

		//cv::Mat frame = cv::imread("./1.bmp");
        ncnn::Mat inmat = ncnn::Mat::from_pixels(frame.data, ncnn::Mat::PIXEL_BGR2RGB, frame.cols, frame.rows);

        std::vector<fcwInfo> fcw_info;
        auto start = chrono::steady_clock::now();
        ultrafcw.detect(inmat, fcw_info);
        auto end = chrono::steady_clock::now();
        chrono::duration<double> elapsed = end - start;
        cout << "all time: " << elapsed.count() << " s" << endl;

        for (int i = 0; i < fcw_info.size(); i++) {
            auto fcw = fcw_info[i];
            cv::Point pt1(fcw.x1, fcw.y1);
            cv::Point pt2(fcw.x2, fcw.y2);
            cv::rectangle(frame, pt1, pt2, cv::Scalar(0, 255, 0), 2);
			str_score<<fcw.score;
			str_score>>fcw_score;
			str_score.clear();
			cv::putText(frame, fcw_score, cv::Point(fcw.x1, fcw.y1+25),
		            cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(0, 0, 255), 2);
        }
		usleep(100000);

        sprintf(filename, "./result%01d.jpg", i-1);
        cv::imwrite(filename, frame);
    }
    return 0;
}
*************************/
